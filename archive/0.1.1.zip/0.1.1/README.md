_v. 0.1.1_  

`rr_utility` : rr_utility
=========================

Description
-----------

This is version 0.1.1 of rr_utility

### License
MIT

Author
------

**Caspar Kaiser**  
Warwick Business School  
caspar.kaiser@wbs.ac.uk  
